// Coded By SKISIFA v1.0.0 | 9/10/2021
const tools = require("./lib/chulda/tools");
const fs = require("fs");
const nodemailer = require("nodemailer");
const pathConfig = "./data/config.json";


let stop = false; 
while(!stop){
    let configSender = strToJson(readJson());
    let what = tools.input("MAILER: ");
    let args = what.split(" ");
    let command = what.split(" ")[0];
    switch (command.toLowerCase()) {
        case "start":
            stop=true;
            startSending();
            break;
        case "exit":
            stop = true;
            break;
        case "show":
            if(args[1] == "smtp"){
                tools.output(showStatus(args[1]));
            }
            else if(args[1] == "send"){
                tools.output(showStatus(args[1]));
            }
            else if(args[1] == "ms"){
                tools.output(showStatus(args[1]));
            }
            else{
                tools.output("Not Found!");
            }
            break;
        case "set":
            if(args[1] == "smtp"){
                setStatus(args[1]);
            }
            else if(args[1] == "send"){
                setStatus(args[1]);
            }
            else if(args[1] == "ms"){
                setStatus(args[1]);
            }
            else{
                tools.output("Not Found!");
            }
            break;
    
        default:
            tools.output("Not Found!");
            break;
    }

}



function startSending(){
    //=====================================
    // create reusable transporter object using the default SMTP transport.
    let configSender = strToJson(readJson());
    //===================================================
    let transporter = nodemailer.createTransport({
        host: configSender.smtp.host,
        port: configSender.smtp.port,
        secure: configSender.smtp.secure,
        auth: {
            user: configSender.smtp.auth.user,
            pass: configSender.smtp.auth.pass
        }
    });
    let listEmails = cleanListEmails(readJsonWithPath(configSender.send.to)); // TODO: NOW
    let lenEmails = listEmails.length; // 4
    let ms = configSender.ms;
    tools.output(`emails: ${lenEmails} | MS: ${ms}`);
    tools.forloop(function(i){
        // send mail with defined transport object
        let mailOptions;
        if(configSender.send.letter.type == "html"){
            mailOptions = {
                from: `${configSender.send.name} <${configSender.send.from}>`, // sender address
                to: `${listEmails[i]}`, // list of receivers
                subject: `${configSender.send.subject}`, // Subject line
                html:`${readJsonWithPath(configSender.send.letter.path)}`, // plain text body
            };
        }
        else if(configSender.send.letter.type == "text"){
            mailOptions = {
                from: `${configSender.send.name} <${configSender.send.from}>`, // sender address
                to: `${listEmails[i]}`, // list of receivers
                subject: `${configSender.send.subject}`, // Subject line
                text:`${readJsonWithPath(configSender.send.letter.path)}`, // plain text body
            };
        }
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.log(`Error[${i}]: [${error}]`);
            }
            else{
                console.log(`Message sent[${i}]: [${listEmails[i]}]`);
                    
            }
        });
    },lenEmails,ms);
}


function showStatus(what){
    let lform; 
    if(what == "smtp"){
        lform = formSmtp();
    }
    else if(what == "send"){
        lform = formSend();
    }
    else if(what == "ms"){
        lform = formMs();
    }
    return lform;

}

function setStatus(what){  // set smtp or send
    let configSender = strToJson(readJson());
    if(what == "smtp"){
        let stop = false;
        while(!stop){
            let one = tools.input("SMTP: ");
            let arg = one.split(" ");
            let cmd = one.split(" ")[0];
            switch (cmd.toLowerCase()) {
                case "done":
                    stop = true;
                    break;
                case "user":
                    configSender.smtp.auth.user = arg[1];
                    break;
                case "pass":
                    configSender.smtp.auth.pass = arg[1];
                    break;
                case "host":
                    configSender.smtp.host = arg[1];
                    break;
                case "port":
                    configSender.smtp.port = arg[1];
                    break;
                    case "secure":
                        configSender.smtp.secure = arg[1];
                        break;
                default:
                    tools.output("Not Found!");
                    break;
            }
        }
    }
    else if(what == "send"){
        let stop = false;
        while(!stop){
            let one = tools.input("SEND: ");
            let arg = one.split(" ");
            let cmd = one.split(" ")[0];
            let n = one.split(arg[0])[1];
            switch (cmd.toLowerCase()) {
                case "done":
                    stop = true;
                    break;
                case "name":
                    configSender.send.name = n;
                    break;
                case "from":
                    configSender.send.from = arg[1];
                    break;
                case "to":
                    configSender.send.to = arg[1];
                    break;
                case "subject":
                    configSender.send.subject = n;
                    break;
                    case "letter":
                        configSender.send.letter.type = arg[1];
                        configSender.send.letter.path = arg[2];
                        break;
                default:
                    tools.output("Not Found!");
                    break;
            }
        }
    }
    else if(what == "ms"){
        let ms = tools.input("MS: ");
        ms = Number(ms);
        configSender.ms = ms;
    }
    updateStatus(configSender);
}
function updateStatus(data){
    let strData = jsonToStr(data);
    writeJson(strData);
}
function formMs(){
    let configSender = strToJson(readJson());
    let t = 
    `
    --[ MS {Status} ]--
    MS: ${configSender.ms}
    ---[END MS]-----    
    `;
    return t;
}

function formSmtp(){
    let configSender = strToJson(readJson());
    let t = 
    `
    -------[ SMTP {Status} ]--------
            * HOST: ${configSender.smtp.host} *
        USER: ${configSender.smtp.auth.user} | PASS: ${configSender.smtp.auth.pass}
        PORT:${configSender.smtp.port} | SECURE: ${configSender.smtp.secure}
    -----------[END SMTP]-----------    
    `;
    return t;
}
function formSend(){
    let configSender = strToJson(readJson());
    let t = 
    `
    -------[ SEND {Status} ]--------
    FROM: ${configSender.send.name} <${configSender.send.from}>
    TO: ${configSender.send.to}
    SUBJECT: ${configSender.send.subject}
        *LETTER*
        type: ${configSender.send.letter.type}
        path: ${configSender.send.letter.path}
    -----------[END SEND]----------- 
    `;
    return t;
}

function cleanListEmails(text){
    let new_text = text.replace(/[\r\n]+/g," ");
    let new_json = new_text.split(" ");
    return new_json;
}

function readJsonWithPath(path){
    let textFile = fs.readFileSync(path,"utf8");
    return textFile;
}
function readJson(){
    let textFile = fs.readFileSync(pathConfig,"utf8");
    return textFile;
}

function writeJson(str){
    fs.writeFileSync(pathConfig,str);
}

function strToJson(str){
    let jsonForm = JSON.parse(str);
    return jsonForm;
}

function jsonToStr(json){
    let strForm = JSON.stringify(json);
    return strForm;
}
